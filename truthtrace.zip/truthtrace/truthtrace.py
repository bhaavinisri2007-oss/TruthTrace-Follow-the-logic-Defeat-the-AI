#!/usr/bin/env python3
"""TruthTrace: check propositional arguments and quiz yourself against an 'AI'."""

import argparse
import itertools
import random
import re
import sys

# ---------------------------------------------------------------------------
# Tokenizer and parser
# ---------------------------------------------------------------------------

TOKEN_RE = re.compile(r"\s*(<->|->|\(|\)|[A-Za-z_][A-Za-z0-9_]*)")
RESERVED = {"not", "and", "or"}


class ParseError(ValueError):
    """Raised when a formula cannot be parsed."""


def tokenize(text):
    text = text.strip()
    if not text:
        raise ParseError("Empty formula")
    tokens, pos = [], 0
    while pos < len(text):
        match = TOKEN_RE.match(text, pos)
        if not match:
            raise ParseError(f"Unexpected character {text[pos]!r} at position {pos}")
        tokens.append(match.group(1))
        pos = match.end()
    return tokens


class Parser:
    """Recursive-descent parser producing nested tuples as an AST.

    Nodes: ("var", name), ("not", x), ("and", a, b), ("or", a, b),
           ("implies", a, b), ("iff", a, b).
    """

    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def advance(self, expected=None):
        tok = self.peek()
        if tok is None:
            raise ParseError("Unexpected end of formula")
        if expected is not None and tok != expected:
            raise ParseError(f"Expected {expected!r} but found {tok!r}")
        self.pos += 1
        return tok

    def parse(self):
        node = self.biconditional()
        if self.peek() is not None:
            raise ParseError(f"Unexpected token {self.peek()!r}")
        return node

    def biconditional(self):
        node = self.implication()
        while self.peek() == "<->":
            self.advance()
            node = ("iff", node, self.implication())
        return node

    def implication(self):
        node = self.disjunction()
        if self.peek() == "->":
            self.advance()
            node = ("implies", node, self.implication())  # right-associative
        return node

    def disjunction(self):
        node = self.conjunction()
        while self.peek() == "or":
            self.advance()
            node = ("or", node, self.conjunction())
        return node

    def conjunction(self):
        node = self.unary()
        while self.peek() == "and":
            self.advance()
            node = ("and", node, self.unary())
        return node

    def unary(self):
        tok = self.peek()
        if tok == "not":
            self.advance()
            return ("not", self.unary())
        if tok == "(":
            self.advance("(")
            node = self.biconditional()
            self.advance(")")
            return node
        tok = self.advance()
        if tok in RESERVED or tok in ("->", "<->", ")"):
            raise ParseError(f"Expected a variable but found {tok!r}")
        return ("var", tok)


def parse(text):
    return Parser(tokenize(text)).parse()


# ---------------------------------------------------------------------------
# Evaluation and validity checking
# ---------------------------------------------------------------------------

def variables_in(node, acc=None):
    if acc is None:
        acc = set()
    if node[0] == "var":
        acc.add(node[1])
    else:
        for child in node[1:]:
            variables_in(child, acc)
    return acc


def evaluate(node, env):
    op = node[0]
    if op == "var":
        return env[node[1]]
    if op == "not":
        return not evaluate(node[1], env)
    a = evaluate(node[1], env)
    b = evaluate(node[2], env)
    if op == "and":
        return a and b
    if op == "or":
        return a or b
    if op == "implies":
        return (not a) or b
    if op == "iff":
        return a == b
    raise ValueError(f"Unknown operator {op!r}")


def check_argument(premises, conclusion):
    """Return (is_valid, counterexample_env_or_None).

    An argument is valid when no assignment makes every premise true
    while the conclusion is false.
    """
    premise_nodes = [parse(p) for p in premises]
    conclusion_node = parse(conclusion)

    names = set()
    for node in premise_nodes + [conclusion_node]:
        variables_in(node, names)
    names = sorted(names)

    for values in itertools.product([True, False], repeat=len(names)):
        env = dict(zip(names, values))
        if all(evaluate(p, env) for p in premise_nodes) and not evaluate(conclusion_node, env):
            return False, env
    return True, None


def format_env(env):
    return ", ".join(f"{name}={'T' if val else 'F'}" for name, val in sorted(env.items()))


def explain(premises, conclusion):
    """Return a human-readable verdict and trace for an argument."""
    valid, env = check_argument(premises, conclusion)
    lines = []
    if valid:
        lines.append(f"VALID: the conclusion '{conclusion}' follows from the premises.")
    else:
        lines.append(f"INVALID: '{conclusion}' does not follow from the premises.")
        lines.append(f"Counterexample: {format_env(env)}")
        for p in premises:
            lines.append(f"  Premise '{p}' is {evaluate(parse(p), env)}")
        lines.append(f"  Conclusion '{conclusion}' is {evaluate(parse(conclusion), env)}")
    return valid, "\n".join(lines)


# ---------------------------------------------------------------------------
# Quiz mode: beat the AI at spotting bad reasoning
# ---------------------------------------------------------------------------

PUZZLES = [
    (["P -> Q", "P"], "Q"),            # modus ponens (valid)
    (["P -> Q", "Q"], "P"),            # affirming the consequent (invalid)
    (["P -> Q", "not Q"], "not P"),    # modus tollens (valid)
    (["P -> Q", "not P"], "not Q"),    # denying the antecedent (invalid)
    (["P or Q", "not P"], "Q"),        # disjunctive syllogism (valid)
    (["P or Q", "P"], "not Q"),        # invalid: P and Q can both be true
    (["P -> Q", "Q -> R"], "P -> R"),  # hypothetical syllogism (valid)
    (["P and Q"], "P"),                # simplification (valid)
    (["P -> Q"], "Q -> P"),            # converse fallacy (invalid)
]


def run_quiz(rounds=5, seed=None):
    rng = random.Random(seed)
    picks = rng.sample(PUZZLES, k=min(rounds, len(PUZZLES)))
    score = 0

    print("The AI is about to make some arguments. Find the ones that don't hold up.\n")
    for number, (premises, conclusion) in enumerate(picks, start=1):
        print(f"Round {number}: the AI argues:")
        for premise in premises:
            print(f"  Premise:    {premise}")
        print(f"  Therefore:  {conclusion}")

        answer = input("Does the conclusion necessarily follow? [y/n] ").strip().lower()
        user_says_valid = answer.startswith("y")
        valid, _ = check_argument(premises, conclusion)

        if user_says_valid == valid:
            score += 1
            print("You defeated the AI this round!")
        else:
            print("The AI wins this round.")

        _, trace = explain(premises, conclusion)
        print(trace + "\n")

    print(f"Final score: you {score} - {len(picks) - score} the AI")
    if score == len(picks):
        print("Flawless. The AI has been defeated.")
    elif score * 2 >= len(picks):
        print("Solid reasoning. The AI barely survived.")
    else:
        print("The AI wins this time. Review the traces and try again.")
    return score


# ---------------------------------------------------------------------------
# Command-line interface
# ---------------------------------------------------------------------------

def build_parser():
    cli = argparse.ArgumentParser(
        prog="truthtrace",
        description="Follow the logic. Defeat the AI.",
    )
    sub = cli.add_subparsers(dest="command", required=True)

    check = sub.add_parser("check", help="check whether a conclusion follows")
    check.add_argument("-p", "--premise", action="append", required=True,
                       help="a premise (repeat for multiple)")
    check.add_argument("-c", "--conclusion", required=True, help="the conclusion")

    quiz = sub.add_parser("quiz", help="beat the AI at spotting bad arguments")
    quiz.add_argument("--rounds", type=int, default=5, help="number of rounds (default 5)")
    quiz.add_argument("--seed", type=int, default=None, help="random seed for repeatable quizzes")
    return cli


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        if args.command == "check":
            _, report = explain(args.premise, args.conclusion)
            print(report)
        elif args.command == "quiz":
            run_quiz(rounds=args.rounds, seed=args.seed)
    except ParseError as err:
        print(f"Parse error: {err}", file=sys.stderr)
        return 2
    except (KeyboardInterrupt, EOFError):
        print("\nQuiz ended.")
        return 130
    return 0


if __name__ == "__main__":
    sys.exit(main())
