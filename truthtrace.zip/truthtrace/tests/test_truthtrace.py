import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from truthtrace import ParseError, check_argument, evaluate, parse


class TestParser(unittest.TestCase):
    def test_implication_is_right_associative(self):
        self.assertEqual(parse("P -> Q -> R"), parse("P -> (Q -> R)"))

    def test_precedence_and_binds_tighter_than_or(self):
        self.assertEqual(parse("P or Q and R"), parse("P or (Q and R)"))

    def test_rejects_bad_input(self):
        for bad in ["", "P ->", "and P", "(P or Q", "P $ Q"]:
            with self.subTest(formula=bad):
                with self.assertRaises(ParseError):
                    parse(bad)


class TestEvaluate(unittest.TestCase):
    def test_truth_values(self):
        env = {"P": True, "Q": False}
        self.assertFalse(evaluate(parse("P and Q"), env))
        self.assertTrue(evaluate(parse("P or Q"), env))
        self.assertFalse(evaluate(parse("P -> Q"), env))
        self.assertTrue(evaluate(parse("Q -> P"), env))
        self.assertFalse(evaluate(parse("P <-> Q"), env))


class TestCheckArgument(unittest.TestCase):
    def test_modus_ponens_is_valid(self):
        valid, _ = check_argument(["P -> Q", "P"], "Q")
        self.assertTrue(valid)

    def test_affirming_consequent_is_invalid(self):
        valid, env = check_argument(["P -> Q", "Q"], "P")
        self.assertFalse(valid)
        self.assertEqual(env, {"P": False, "Q": True})

    def test_contradictory_premises_are_vacuously_valid(self):
        valid, _ = check_argument(["P", "not P"], "Q")
        self.assertTrue(valid)


if __name__ == "__main__":
    unittest.main()
